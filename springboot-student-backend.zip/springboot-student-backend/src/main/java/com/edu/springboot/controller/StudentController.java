package com.edu.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edu.springboot.model.Student;
import com.edu.springboot.service.StudentService;

@RestController
@CrossOrigin(allowedHeaders = "*",origins="*")
public class StudentController {
	@Autowired
	private StudentService studentservice;
   @PostMapping("/registerStudent")
	public Student registerStudent(@RequestBody Student student) {
		return studentservice.registerStudent(student);
	}
   
   @GetMapping("/getStudents")
   public List<Student> getStudents(){
	   return studentservice.getStudents();
   }
   @DeleteMapping("/deleteStudent")
   public void deleteStudent(@RequestParam Integer id) {
	   studentservice.deleteStudent(id);
   }
   @PutMapping("/updateStudent")
   public Student updateStudent(@RequestBody Student student) {
	  return studentservice.updateStudent(student);
   }
   
}
