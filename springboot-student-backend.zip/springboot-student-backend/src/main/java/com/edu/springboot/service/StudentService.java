package com.edu.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.springboot.model.Student;
import com.edu.springboot.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	private StudentRepository studentrepository;
    public Student registerStudent(Student student) {
    	return studentrepository.save(student);//insert 
    }
    
    public List<Student> getStudents(){
    	return studentrepository.findAll(); //select all records
    	
    }
    
    public void deleteStudent(Integer id) {
    	studentrepository.deleteById(id); //delete particular record
    }
    
    public Student updateStudent(Student student) {  //update
    	Integer rollNumber=student.getRollNumber();
    	Student std = studentrepository.findById(rollNumber).get();
    	std.setName(student.getName());
    	std.setAddress(student.getAddress());
    	std.setPercentage(student.getPercentage());
    	return studentrepository.save(std);
    	
    }
}
