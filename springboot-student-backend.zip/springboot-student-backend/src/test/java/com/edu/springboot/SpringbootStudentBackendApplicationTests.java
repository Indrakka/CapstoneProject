package com.edu.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootStudentBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
